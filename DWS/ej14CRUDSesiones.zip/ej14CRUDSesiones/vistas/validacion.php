<?php

echo "<form action='' method='post'>";
echo "dni: <input type='text' name='dni'><br/>";
echo "Contraseña: <input type='text' name='pass'><br/>";
echo "<input type='submit' name='enviarPass'>";
echo "</form>";